#SXD20|20011|80012|70210|2019.01.24 23:58:32|school|utf8|1|0|
#TA courses`0`16384
#EOH

#	TC`courses`utf8_general_ci	;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `tuts` int(11) unsigned DEFAULT NULL,
  `homeworks` int(11) unsigned DEFAULT NULL,
  `level` varchar(191) DEFAULT NULL,
  `price` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8	;
