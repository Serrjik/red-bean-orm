#SXD20|20011|50719|70107|2019.01.25 16:53:20|school|utf8|1|5|
#TA courses`5`16384
#EOH

#	TC`courses`utf8_general_ci	;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `tuts` int(11) unsigned DEFAULT NULL,
  `homeworks` int(11) unsigned DEFAULT NULL,
  `level` varchar(191) DEFAULT NULL,
  `price` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`courses`utf8_general_ci	;
INSERT INTO `courses` VALUES 
(9,'React - ступень 1-я',20,8,'Для новичков',80),
(10,'Курс по React',10,8,'Для новичков',100),
(11,'Курс по React',10,8,'Для новичков',100),
(12,'Курс по верстке',6,25,'Для новичков',80),
(13,'Курс по верстке',6,25,'Для новичков',80)	;
