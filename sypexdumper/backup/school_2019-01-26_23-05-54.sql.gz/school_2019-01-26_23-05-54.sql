#SXD20|20011|80012|70210|2019.01.26 23:05:54|school|utf8|1|5|
#TA courses`5`16384
#EOH

#	TC`courses`utf8_general_ci	;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `tuts` int(11) unsigned DEFAULT NULL,
  `homeworks` int(11) unsigned DEFAULT NULL,
  `level` varchar(191) DEFAULT NULL,
  `price` int(11) unsigned DEFAULT NULL,
  `students` int(11) unsigned DEFAULT NULL,
  `img` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`courses`utf8_general_ci	;
INSERT INTO `courses` VALUES 
(9,'React - ступень 1-я',20,8,'Для новичков',80,\N,\N),
(10,'React - ступень 2-я',25,8,'Для новичков',155,20,'<img src=\'react.png\'>'),
(11,'Курс по React',10,8,'Для новичков',100,\N,\N),
(12,'Курс по верстке',6,25,'Для новичков',80,\N,\N),
(13,'Курс по верстке',6,25,'Для новичков',80,\N,\N)	;
